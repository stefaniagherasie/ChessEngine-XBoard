package engine;

import java.util.ArrayList;

import auxiliary.Pair;
import auxiliary.Position;

public class LimitedTimeStrategy implements Strategy{

	@Override
	public double eval(boolean player) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ArrayList<Pair<Position, Position>> nextMoves() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getDepth() {
		// TODO Auto-generated method stub
		return 0;
	}

}
