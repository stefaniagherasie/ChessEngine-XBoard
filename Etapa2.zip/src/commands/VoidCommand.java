package commands;

public class VoidCommand extends Command{
	
	@Override
	public void execute() {
		//noting to do
	}
}
