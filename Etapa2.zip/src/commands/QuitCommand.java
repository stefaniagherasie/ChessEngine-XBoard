package commands;

public class QuitCommand  extends Command {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
