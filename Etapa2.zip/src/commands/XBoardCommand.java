package commands;

public class XBoardCommand extends Command{

	@Override
	public void execute() {
		
	}
}
