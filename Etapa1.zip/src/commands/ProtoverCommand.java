package commands;

public class ProtoverCommand extends Command{

	@Override
	public void execute() {
		System.out.println("feature sigint=0");
	}
	
}
